from django.test import TestCase

# Create your tests here.
# no automated tests were developed for this application